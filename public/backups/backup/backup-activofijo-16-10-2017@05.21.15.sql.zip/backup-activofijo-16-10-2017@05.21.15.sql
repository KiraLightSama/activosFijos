-- # A Mysql Backup System
-- # Export created: 2017/10/16 on 17:21:15
-- # Database : activofijo
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `detallebaja`
DROP TABLE  IF EXISTS `detallebaja`;
CREATE TABLE `detallebaja` (
  `cantidad` int(11) NOT NULL AUTO_INCREMENT,
  `bajas_id` int(11) NOT NULL,
  `activos_id` int(11) NOT NULL,
  PRIMARY KEY (`cantidad`),
  KEY `fk_bajas_has_activos_activos1_idx` (`activos_id`),
  KEY `fk_bajas_has_activos_bajas1_idx` (`bajas_id`),
  CONSTRAINT `fk_bajas_has_activos_activos1` FOREIGN KEY (`activos_id`) REFERENCES `activos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_bajas_has_activos_bajas1` FOREIGN KEY (`bajas_id`) REFERENCES `bajas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1; 
COMMIT; 
SET AUTOCOMMIT = 1; 
