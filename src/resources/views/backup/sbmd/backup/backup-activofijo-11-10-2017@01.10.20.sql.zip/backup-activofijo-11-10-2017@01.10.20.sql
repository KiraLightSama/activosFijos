-- # A Mysql Backup System
-- # Export created: 2017/10/11 on 01:10
-- # Database : activofijo
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `plancuenta`
DROP TABLE  IF EXISTS `plancuenta`;
CREATE TABLE `plancuenta` (
  `cuentas_id` int(11) NOT NULL,
  `gestiones_id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cuentas_id`,`gestiones_id`),
  KEY `fk_cuentas_has_gestiones_gestiones1_idx` (`gestiones_id`),
  KEY `fk_cuentas_has_gestiones_cuentas1_idx` (`cuentas_id`),
  CONSTRAINT `fk_cuentas_has_gestiones_cuentas1` FOREIGN KEY (`cuentas_id`) REFERENCES `cuentas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cuentas_has_gestiones_gestiones1` FOREIGN KEY (`gestiones_id`) REFERENCES `gestiones` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1; 
COMMIT; 
SET AUTOCOMMIT = 1; 
