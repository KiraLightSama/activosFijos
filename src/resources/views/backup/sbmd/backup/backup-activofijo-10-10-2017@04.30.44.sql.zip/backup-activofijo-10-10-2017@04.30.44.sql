-- # A Mysql Backup System
-- # Export created: 2017/10/10 on 04:30
-- # Database : activofijo
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `users`
DROP TABLE  IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `empleados_id` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`empleados_id`),
  KEY `fk_users_empleados1_idx` (`empleados_id`),
  CONSTRAINT `fk_users_empleados1` FOREIGN KEY (`empleados_id`) REFERENCES `empleados` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `status`, `empleados_id`, `remember_token`, `created_at`, `updated_at`) VALUES (1, 'javier', 'javier.navia.033@gmail.com', '$2y$10$6JleMEDZwYd0VKR4AimVmOZbE8cJrVEOlYyl9EKIDicVKZ9/E7VUy', 1, 1, 'irN2evzlsS85onlGmcWxCfjnZOVwrHcMyU5GfZcpOw934chw3y58PU2dnge3', '2017-09-19 11:47:47', '2017-09-19 11:47:47'), 
(2, 'Soledad Barea', 'SOLEDAD@GMAIL.COM', '$2y$10$uKZnvcGU2eh5l4r3wobqgetpO5aby0.FDvKh9B3pXqHPE6frc7CTi', 1, 1, 'mCmSeq2KayABRai2Oaa4gRdRkUTsXPJ5oz5Z3MMxxrigTxSU09bhCAD9hgh4', '2017-09-19 11:58:31', '2017-09-19 11:58:31'), 
(3, 'LUIS', 'LUIS.VALLEJOS@FINNING.COM', '$2y$10$HGsKy4oqFmgegrLyRHVX4.jw4W6/5wdz5h5ygOBz9GkMS8bzTi.sO', 0, 1, '', '2017-09-18 20:49:19', '2017-09-18 20:49:19');

SET FOREIGN_KEY_CHECKS = 1; 
COMMIT; 
SET AUTOCOMMIT = 1; 
