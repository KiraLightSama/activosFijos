







        <!-- PAGE FOOTER -->
        		<div class="page-footer">
        			<div class="row">
        				<div class="col-xs-12 col-sm-6">
        					<span class="txt-color-white">UAGRM <span class="hidden-xs"> - Sistema de Informacion II</span> © 2017</span>
        				</div>

        				<div class="col-xs-6 col-sm-6 text-right hidden-xs">
        					<div class="txt-color-white inline-block">
        						<i class="txt-color-blueLight hidden-mobile">Desarrollado por: <i class="fa fa-clock-o"></i> <strong>
										Grupo V </a> &nbsp;</strong> </i>
        								</ul>
        						</div>
        					</div>
        				</div>
        			</div>
        		<!-- END PAGE FOOTER -->
